from .kings_pokeapi import get_poke_details

__all__ = ['get_poke_details']