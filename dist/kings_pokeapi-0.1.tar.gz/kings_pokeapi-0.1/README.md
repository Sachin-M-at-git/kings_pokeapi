# Pokémon API

A web API that scrapes Pokémon data from the Pokémon Database.

## Disclaimer
All content & design © Pokémon Database, 2008-2024. Pokémon images & names © 1995-2024 Nintendo/Game Freak. This project is not affiliated with or endorsed by Nintendo or Game Freak.

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.
